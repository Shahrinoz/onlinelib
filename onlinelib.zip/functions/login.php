<?php 

class Login{
    
    /* __constructor()
     * Constructor will be called every time Login class is called ($login = new Login())
     */
     public function __construct(){

        /* If logout button is pressed call logOut() function. */
        if (isset($_POST["logout"])) {
            $this->logOut();
        }
        
        /* First check if user is logged in. */
        $this->isLoggedIn();
         
        /* If login data is posted call validation function. */
        if (isset($_POST["login"])) {
            $this->validateLogIn();
        }     
                       
    } /* End __construct() */
    
 
    /* function validateLogIn()
     * Function that validates user login data, cross-checks with database.
     */
    public function validateLogIn(){
    
    /* Require credentials for DB connection. */
   // require ('config/dbconnect.php');
        
    /* Check that data has been submited through login form */
    if(isset($_POST['login'])){

      if (($_POST['username']=='shahrinoz') && ($_POST['password']=='1234')){
        $_SESSION['user_id'] = 'Shahrinoz Elmurodova';
      }else{
        $_SESSION['errorMessage'] = 'Please try again.';
      }
        

    } /* End validateLogIn() */
  
    }
    /* function isLoggedIn()
     * Check if user is already logged in, if not then prompt login form.
     */
    public function isLoggedIn(){
        
    /* Require credentials for DB connection. */
   // require ('config/dbconnect.php');

        if(!empty(@$_SESSION['user_id'])){   
            return true;        
        } else {    
            return false;
        }

    } /* End isLoggedIn() */
    
    
    /* function logOut()
     * Logs user out, destroys all session data.
     */
    public function logOut(){
        
        session_destroy();  // Destroy all session data.
        header('Location: index.php');
        
    } /* End logOut() */   
    
    
} /* End class Login */


